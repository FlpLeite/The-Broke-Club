<template>
  <footer class="bg-white py-6 border-t">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <div class="mb-4 md:mb-0">
          <p class="text-sm text-gray-500">
            &copy; {{ new Date().getFullYear() }} Controlador de Investimentos. Todos os direitos reservados.
          </p>
        </div>
        <div class="flex space-x-6">
          <a href="#" class="text-gray-400 hover:text-gray-500">
            <span class="sr-only">Política de Privacidade</span>
            Política de Privacidade
          </a>
          <a href="#" class="text-gray-400 hover:text-gray-500">
            <span class="sr-only">Termos de Serviço</span>
            Termos de Serviço
          </a>
          <a href="#" class="text-gray-400 hover:text-gray-500">
            <span class="sr-only">Contato</span>
            Contato
          </a>
        </div>
      </div>
    </div>
  </footer>
</template>